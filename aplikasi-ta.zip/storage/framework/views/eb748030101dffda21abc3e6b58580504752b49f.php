<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <title>Sentra Pelayanan Kepolisian Terpadu</title>

    
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    <!-- Mobile Specific Metas-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

    <!-- Template Style-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="<?php echo e(asset('assets-user/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets-user/css/jquery-fancybox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets-user/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets-user/css/shortcodes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets-user/css/responsive.css')); ?>">

    <link href="favicon.ico" rel="shortcut icon">
</head>

<body class="counter-scroll">
    <div id="loading-overlay">
        <div class="loader"></div>
    </div><!-- loading -->

    
    <?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <section id="main">
        <div class="container py-5">
            <h1 style="color: black" class="h1 font-weight-bolder text-center my-4" data-aos="fade-up"
                data-aos-duration="500">Pilihan Layanan</h1>
            <div class="row py-5" data-aos="fade-up" data-aos-duration="500" data-aos-delay="200">
                
                <div class="col-6">
                    <div class="card shadow-lg">
                        <img class="card-img-top" width="100%"
                            src="<?php echo e(asset('assets-user/img/rev-slider/gambar1.jpg')); ?>" alt="Pengaduan Masyarakat">
                        <div class="card-body">
                            <h5 class="d-inline-block h6" style="color: black">Pengaduan Masyarakat</h5>

                            <div class="d-inline-block dropdown">
                                <button class="btn btn-light" type="button" id="dropdownMenuButton"
                                    data-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-caret-down"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="/pengaduan-masyarakat/sktlk">SKTLK (Surat Keterangan Tanda Lapor
                                        Kehilangan)</a>
                                    <a class="dropdown-item" href="/pengaduan-masyarakat/sik">Surat Izin Keramaian</a>
                                    <a class="dropdown-item" href="/pengaduan-masyarakat/sttlp">STTLP</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-6">
                    <div class="card shadow-lg">
                        <img class="card-img-top" width="100%"
                            src="<?php echo e(asset('assets-user/img/rev-slider/gambar1.jpg')); ?>" alt="Pengaduan Masyarakat">
                        <div class="card-body">
                            <h5 class="d-inline-block h6" style="color: black">Penindaklanjutan Tindak Kriminal</h5>

                            <div class="d-inline-block dropdown">
                                <button class="btn btn-light" type="button" id="dropdownMenuButton"
                                    data-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-caret-down"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="/tindak-kriminal">Tindak Kriminal</a>
                                    <a class="dropdown-item" href="/tindak-kriminal/sp2hp">SP2HP</a>
                                    <a class="dropdown-item" href="/tindak-kriminal/sttlp">STTLP</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <script src="<?php echo e(asset('assets-user/js/jquery.min.js')); ?>"></script>

    
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
    </script>

    <script src="<?php echo e(asset('assets-user/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-user/js/main.js')); ?>"></script>

    <!-- Slider -->
    <script src="<?php echo e(asset('assets-user/rev-slider/js/jquery.themepunch.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/jquery.themepunch.revolution.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-user/js/rev-slider.js')); ?>"></script>

    <!-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.actions.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.carousel.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.kenburn.min.js')); ?>">
    </script>
    <script
        src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.layeranimation.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.migration.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.navigation.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.parallax.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.slideanims.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('assets-user/rev-slider/js/extensions/extensionsrevolution.extension.video.min.js')); ?>">
    </script>
</body>

</html>
<?php /**PATH C:\Users\galuh\Downloads\aplikasi-ta\aplikasi-ta\resources\views/beranda.blade.php ENDPATH**/ ?>